## Obsolete Config Files From Docs

These config files were originally from docs, but have been separated
and put here to be used by various tests.


[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/test/fixtures/doc-yaml/README.md?pixel)]()
