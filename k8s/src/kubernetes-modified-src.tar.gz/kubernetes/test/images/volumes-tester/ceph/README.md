# Ceph server container for testing

This container exports ceph fs with an index.html inside.

Used by test/e2e/* to test CephFSVolumeSource. Not for production use!


[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/test/images/volumes-tester/ceph/README.md?pixel)]()
